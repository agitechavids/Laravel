<footer class="margin-tb-3">
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; Bhutan 2019</p>
        </div>
    </div>
</footer>