<p>Posted by <span class="glyphicon glyphicon-user"></span> <a href="#">Debasish Sahoo</a> on <span class="glyphicon glyphicon-time"></span> 22 July 2019 10:00 am</p>
@extends('layouts.master')
@section('title', 'LARAVEL ABOUT PAGE')
@section('content')
<h2>This is my About page</h2>
@stop