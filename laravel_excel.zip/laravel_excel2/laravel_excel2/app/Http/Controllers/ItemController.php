<?php
namespace App\Http\Controllers;
use App\Item;
use Excel;
use Illuminate\Http\Request;

    class ItemController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function index()
        {
            $items=Item::paginate(15);
            return view('items',compact('items'));
        }

        /**
         * import a file in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function import(Request $request)
        {
        if($request->file('imported-file'))
        {
                    $path = $request->file('imported-file')->getRealPath();
                    $data = Excel::load($path, function($reader)
            {
                    })->get();

            if(!empty($data) && $data->count())
            {
                foreach ($data->toArray() as $row)
                {
                if(!empty($row))
                {
                    $dataArray[] =
                    [
                    'item_name' => $row['name'],
                    'item_code' => $row['code'],
                    'item_price' => $row['price'],
                    'item_qty' => $row['quantity'],
                    'item_tax' => $row['tax'],
                    'item_status' => $row['status'],
                    'created_at' => now(),
                    'updated_at' => now()
                    ];
                }
            }
            if(!empty($dataArray))
            {
                Item::insert($dataArray);
                return back();
            }
            }
        }
        }

        public function export(){
            $items = Item::all();
            return Excel::create('items', function($excel) use($items) {
                $excel->sheet('ExportFile', function($sheet) use($items) {
                    $sheet->fromArray($items);
                });
            })->download('csv');
    
        }
        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Http\Response
         */
        public function create()
        {
            //
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function store(Request $request)
        {
            //
        }

        /**
         * Display the specified resource.
         *
         * @param  \App\Item  $item
         * @return \Illuminate\Http\Response
         */
        public function show(Item $item)
        {
            //
        }

        /**
         * Show the form for editing the specified resource.
         *
         * @param  \App\Item  $item
         * @return \Illuminate\Http\Response
         */
        public function edit(Item $item)
        {
            //
        }

        /**
         * Update the specified resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  \App\Item  $item
         * @return \Illuminate\Http\Response
         */
        public function update(Request $request, Item $item)
        {
            //
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Item  $item
         * @return \Illuminate\Http\Response
         */
        public function destroy(Item $item)
        {
            //
        }

    }
