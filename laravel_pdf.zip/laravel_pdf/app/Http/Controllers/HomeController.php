<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PDF;
class HomeController extends Controller

{

    public function downloadPDF()

    {

    	$pdf = PDF::loadView('pdfView');

		return $pdf->download('invoice.pdf');

    }

}