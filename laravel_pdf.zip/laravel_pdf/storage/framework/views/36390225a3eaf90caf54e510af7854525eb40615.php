<!-- master.blade.php -->

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/app.css">
  </head>
  <body>
      <div class="container">
          <?php echo $__env->yieldContent('content'); ?>
      </div>
  </body>
</html>