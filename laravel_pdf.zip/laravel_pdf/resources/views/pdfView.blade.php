<!DOCTYPE html>

<html>

<head>

	<title>Load PDF</title>

	<style type="text/css">

		table{

			width: 100%;

			border:1px solid black;

		}

		td, th{

			border:1px solid black;

		}

	</style>

</head>

<body>



<h2>Load PDF File</h2>

<table>

	<tr>

		<th>No.</th>

		<th>Name</th>

	</tr>

	<tr>

		<td>1</td>

		<td>Sourav</td>

	</tr>

	<tr>

		<td>2</td>

		<td>Debasish</td>

	</tr>

	<tr>

		<td>1</td>

		<td>Souvhik</td>

	</tr>

</table>



</body>

</html>