<!-- pdf.blade.php -->

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <style type="text/css">

		table{

			width: 100%;

			border:1px solid black;

		}

		td, th{

			border:1px solid black;

		}

	</style>
  </head>
  <body>
    <table class="table table-bordered">
    <tr>
    <th>FULL NAME</th>
    <th>STREET ADDRESS</th>
    <th>CITY</th>
    <th>ZIP CODE</th>
    </tr>

    @foreach ($users as $user)
      <tr>
        <td>
          {{$user->full_name}}
        </td>
        <td>
          {{$user->street_address}}
        </td>
        <td>
          {{$user->city}}
        </td>
        <td>
          {{$user->zip_code}}
        </td>
      </tr>
    @endforeach


    </table>
  </body>
</html>