<!DOCTYPE html>
<html>
<head>
@include('layouts.header')
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

@include('layouts.mainheader')
  <!-- Left side column. contains the logo and sidebar -->
  @include('layouts.leftsidebar')

  <!-- Content Wrapper. Contains page content -->
  @include('layouts.content')
  <!-- /.content-wrapper -->
  @include('layouts.footer')

  <!-- Control Sidebar -->
  @include('layouts.rightsidebar')
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
@include('layouts.script')
</body>
</html>
